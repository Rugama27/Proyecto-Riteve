/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import BaseDatos.MariaDB;
import Dao.CitaDao;
import Modelo.Cita;
import Vista.Vista;

/**
 *
 * @author Luis Rugama
 */
public class ControlCitas implements Control<Cita> {

    private Vista vista;
    private MariaDB bd;
    private CitaDao dao;

    public ControlCitas(Vista vista) {
        this.vista = vista;
        this.bd = new MariaDB("127.0.0.1", "dbriteve", "root", "");
        this.dao = new CitaDao(this.bd);
    }

    @Override
    public void guardar(Cita cita) {
        if (dao.validarPk(cita)) {
            if (dao.insertar(cita)) {
                Object[] mensaje = {"Se registro con existo"};
                vista.notificar(mensaje);
                vista.cerrarVentana();
            } else {
                Object[] mensaje = {"Error al registrase"};
                vista.notificar(mensaje);
            }
        } else {
            Object[] mensaje = {"Error al registrase\nEl numero de cedula " + cita.getId() + " ya existe."};
            vista.notificar(mensaje);
        }
    }

    public void modificarCita(Cita cita) {
        if (dao.modificar(cita)) {
            Object[] mensaje = {"Cita modificada"};
            vista.notificar(mensaje);
            vista.cerrarVentana();
        } else {
            Object[] mensaje = {"Error al modificar"};
            vista.notificar(mensaje);
            System.out.println(bd.getError());
        }
    }

    @Override
    public void eliminar(Cita cita) {
        if (dao.eliminar(cita)) {
            Object[] mensaje = {"Cita eliminada"};
            vista.notificar(mensaje);
        } else {
            Object[] mensaje = {"Error al eliminar"};
            vista.notificar(mensaje);
        }
    }

    @Override
    public void cancelar() {
        vista.cerrarVentana();
    }

    @Override
    public void filtrar(String busqueda) {
        Cita[] cita = this.dao.filtrar(busqueda);
        if (cita != null) {
            vista.mostrar(cita);
        } else {
            Object[] mensaje = {"No hay resultados"};
            vista.notificar(mensaje);
        }
    }

    @Override
    public void cargar() {
        //El try catch Captura el error que se genera cuando 
        //la tabla de vehiculos esta vacia en la base de datos
        try {
            vista.mostrar(dao.listar());
        } catch (NullPointerException e) {
        }
    }

    @Override
    public Cita buscar(Cita clase) {
        return null;
    }

    @Override
    public void modificar(Cita clase, String str) {
    }

}
