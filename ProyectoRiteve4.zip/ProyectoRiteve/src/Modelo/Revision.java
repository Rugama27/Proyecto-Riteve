package Modelo;

import java.sql.*;

/**
 *
 * @author Luis Rugama
 */
public class Revision {

    private int id;
    private Date fecha;
    private String hora;
    private Tecnico tecnico;
    private String tipoRevision;
    private String observaciones;
    private String estado;

    public Revision(int id, Date fecha, String hora, Tecnico tecnico, String tipoRevision, String observaciones, String estado) {
        this.fecha = fecha;
        this.hora = hora;
        this.tecnico = tecnico;
        this.tipoRevision = tipoRevision;
        this.observaciones = observaciones;
        this.estado = estado;
        this.id = id;
    }

    public Revision() {
        this(0, null, null, null, null, null, null);
    }

    public Date getFecha() {
        return fecha;
    }

    public String getHora() {
        return hora;
    }

    public Tecnico getTecnico() {
        return tecnico;
    }

    public String getTipoRevision() {
        return tipoRevision;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public String getEstado() {
        return estado;
    }

    public int getId() {
        return id;
    }
}
