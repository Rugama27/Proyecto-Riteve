package Dao;

/**
 *
 * @author Alvarado Ruiz
 * @param <Clase>
 */
public interface Dao<Clase> {

    public boolean insertar(Clase ob);

    public boolean modificar(Clase ob, String str);

    public boolean eliminar(Clase ob);

    public Clase buscar(Clase ob);

    public Clase[] listar();

    public Clase[] filtrar(String nombre);

    public boolean validarPk(Clase ob);
    
}
