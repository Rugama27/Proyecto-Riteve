package Controlador;

import BaseDatos.MariaDB;
import Dao.UsuarioDao;
import Modelo.Usuario;
import Vista.Vista;

/**
 *
 * @author Alvarado Ruiz
 */
public class ControlUsuarios implements Control<Usuario> {

    private Vista vista;
    private MariaDB bd;
    private UsuarioDao dao;

    public ControlUsuarios(Vista vista) {
        this.vista = vista;
        this.bd = new MariaDB("127.0.0.1", "dbriteve", "root", "");
        this.dao = new UsuarioDao(this.bd);
    }

    @Override
    public void guardar(Usuario usuario) {
        if (dao.validarPk(usuario)) {
            if (dao.insertar(usuario)) {
                Object[] mensaje = {"Se registro con existo"};
                vista.notificar(mensaje);
                vista.cerrarVentana();
            } else {
                Object[] mensaje = {"Error al registrase"};
                vista.notificar(mensaje);
            }
        } else {
            Object[] mensaje = {"Error al registrase\nEl numero de cedula " + usuario.getCedula() + " ya exsite."};
            vista.notificar(mensaje);
        }
    }

    @Override
    public void modificar(Usuario usuario, String cedula) {
        if (dao.modificar(usuario, cedula)) {
            Object[] mensaje = {"Registro modificado"};
            vista.notificar(mensaje);
            vista.cerrarVentana();
        } else {
            Object[] mensaje = {"Error al modificar"};
            vista.notificar(mensaje);
        }
    }

    @Override
    public void eliminar(Usuario usuario) {
        if (dao.eliminar(usuario)) {
            Object[] mensaje = {"Registro eliminado"};
            vista.notificar(mensaje);
        } else {
            Object[] mensaje = {"Error al eliminar"};
            vista.notificar(mensaje);
        }
    }

    @Override
    public void filtrar(String busqueda) {
        Usuario[] usuario = this.dao.filtrar(busqueda);
        if (usuario != null) {
            vista.mostrar(usuario);
        } else {
            Object[] mensaje = {"No hay resultados"};
            vista.notificar(mensaje);
        }
    }

    //Comprueba que la contraseña ingresada en Iniciar Sesion sea correcta
    public boolean validarLogin(Usuario usuario, String contrasenia) {
        if (dao.buscar(usuario) != null) {
            return dao.buscar(usuario).getContrasenia().equals(contrasenia);
        } else {
            return false;
        }
    }

    //Cancela el preceso de registro, se sale de la ventana actual.
    @Override
    public void cancelar() {
        vista.cerrarVentana();
    }

    //Carga la informacion de la base de datos.
    @Override
    public void cargar() {
        vista.mostrar(dao.listar());
    }

}
