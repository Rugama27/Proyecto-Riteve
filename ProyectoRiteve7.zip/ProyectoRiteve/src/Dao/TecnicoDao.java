package Dao;

import BaseDatos.BaseDatos;
import Modelo.Tecnico;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 *
 * @author Luis Rugama
 */
public class TecnicoDao implements Dao<Tecnico> {

    private BaseDatos db;

    public TecnicoDao(BaseDatos db) {
        this.db = db;
    }

    @Override
    public boolean insertar(Tecnico tecnico) {
        this.db.prepararSentencia("Insert into tecnicos values (?,?,?,?,?,?)");
        Object[] param = {tecnico.getCedula(), tecnico.getNombreCompleto(), tecnico.getFechaNacimiento(), tecnico.getTelefono(),
            tecnico.getCorreoElectronico(), tecnico.getSalario(),};
        return this.db.ejecutar(param);
    }

    @Override
    public boolean modificar(Tecnico tecnico, String cedula) {
        this.db.prepararSentencia("Update tecnicos set Cedula=?, NombreCompleto=?, FechaNacimiento=?, Telefono=?, "
                + "CorreoElectronico=?, Salario=? where Cedula=?");
        Object[] param = {tecnico.getCedula(), tecnico.getNombreCompleto(), tecnico.getFechaNacimiento(), tecnico.getTelefono(),
            tecnico.getCorreoElectronico(), tecnico.getSalario(), cedula};
        return this.db.ejecutar(param);
    }

    @Override
    public boolean eliminar(Tecnico tecnico) {
        this.db.prepararSentencia("Delete from tecnicos where Cedula=?");
        Object[] param = {tecnico.getCedula()};
        return this.db.ejecutar(param);
    }

    @Override
    public Tecnico buscar(Tecnico tecnico) {
        this.db.prepararSentencia("Select * from tecnicos where NombreCompleto=?");
        Object[] param = {tecnico.getNombreCompleto()};
        Object[][] valores;
        valores = this.db.seleccionar(param);
        if (valores.length > 0) {
            return new Tecnico((int) valores[0][0], String.valueOf(valores[0][1]), fecha(String.valueOf(valores[0][2])),
                    (int) valores[0][3], String.valueOf(valores[0][4]), (Double) valores[0][5]);
        } else {
            return null;
        }
    }

    //Busca un usuario en base a su cedula y devuelve un usuario
    public Tecnico buscarPorCedula(Tecnico tecnico) {
        this.db.prepararSentencia("Select * from tecnicos where Cedula=?");
        Object[] param = {tecnico.getCedula()};
        Object[][] valores;
        valores = this.db.seleccionar(param);
        if (valores.length > 0) {
            return new Tecnico((int) valores[0][0], String.valueOf(valores[0][1]), fecha(String.valueOf(valores[0][2])),
                    (int) valores[0][3], String.valueOf(valores[0][4]), (Double) valores[0][5]);
        } else {
            return null;
        }
    }

    @Override
    public Tecnico[] listar() {
        this.db.prepararSentencia("Select * from tecnicos order by Cedula");
        Object[] param = {};
        Object[][] valores;
        valores = this.db.seleccionar(param);
        if (valores.length > 0) {
            Tecnico[] tecnico = new Tecnico[valores.length];
            for (int f = 0; f < valores.length; f++) {
                tecnico[f] = new Tecnico((int) valores[f][0], String.valueOf(valores[f][1]), fecha(String.valueOf(valores[f][2])),
                        (int) valores[f][3], String.valueOf(valores[f][4]), (Double) valores[f][5]);

            }
            return tecnico;
        } else {
            return null;
        }
    }

    public Date fecha(String fecha) {
        try {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            java.util.Date parsed;
            parsed = format.parse(fecha);
            java.sql.Date sql = new java.sql.Date(parsed.getTime());
            return sql;
        } catch (ParseException ex) {
            return null;
        }
    }

    @Override
    public Tecnico[] filtrar(String nombre) {
        this.db.prepararSentencia("Select * from tecnicos where NombreCompleto like (?) order by Cedula");
        Object[] param = {nombre + "%"};
        Object[][] valores;
        valores = this.db.seleccionar(param);
        if (valores != null && valores.length > 0) {
            Tecnico[] tecnico = new Tecnico[valores.length];
            for (int f = 0; f < valores.length; f++) {
                tecnico[f] = new Tecnico((int) valores[f][0], String.valueOf(valores[f][1]), fecha(String.valueOf(valores[f][2])),
                        (int) valores[f][3], String.valueOf(valores[f][4]), (Double) valores[f][5]);
            }
            return tecnico;
        } else {
            return null;
        }
    }

    @Override
    public boolean validarPk(Tecnico tecnico) {
        tecnico = buscarPorCedula(tecnico);
        return tecnico == null;
    }

}
