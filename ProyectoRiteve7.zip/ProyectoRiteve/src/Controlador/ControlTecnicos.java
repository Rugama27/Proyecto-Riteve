/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import BaseDatos.MariaDB;
import Dao.TecnicoDao;

import Modelo.Tecnico;
import Vista.Vista;

/**
 *
 * @author Luis Rugama
 */
public class ControlTecnicos implements Control<Tecnico> {

    private Vista vista;
    private MariaDB bd;
    private TecnicoDao dao;

    public ControlTecnicos(Vista vista) {
        this.vista = vista;
        this.bd = new MariaDB("127.0.0.1", "dbriteve", "root", "");
        this.dao = new TecnicoDao(this.bd);
    }

    @Override
    public void guardar(Tecnico tecnico) {
        if (dao.validarPk(tecnico)) {
            if (dao.insertar(tecnico)) {
                Object[] mensaje = {"Se registro con existo"};
                vista.notificar(mensaje);
                vista.cerrarVentana();
            } else {
                Object[] mensaje = {"Error al registrase"};
                vista.notificar(mensaje);
                System.out.println(bd.getError());
            }
        } else {
            Object[] mensaje = {"Error al registrase\nEl numero de cedula " + tecnico.getCedula() + " ya existe."};
            vista.notificar(mensaje);
        }
    }

    @Override
    public void modificar(Tecnico tecncio, String cedula) {
        if (dao.modificar(tecncio, cedula)) {
            Object[] mensaje = {"Tecnico modificado"};
            vista.notificar(mensaje);
            vista.cerrarVentana();
        } else {
            Object[] mensaje = {"Error al modificar"};
            vista.notificar(mensaje);
            System.out.println(bd.getError());
        }
    }

    @Override
    public void eliminar(Tecnico tecnico) {
        if (dao.eliminar(tecnico)) {
            Object[] mensaje = {"Tecnico eliminado"};
            vista.notificar(mensaje);
        } else {
            Object[] mensaje = {"Error al eliminar"};
            vista.notificar(mensaje);
        }
    }

    @Override
    public void cancelar() {
        vista.cerrarVentana();
    }

    @Override
    public void filtrar(String busqueda) {
        Tecnico[] tecnico = this.dao.filtrar(busqueda);
        if (tecnico != null) {
            vista.mostrar(tecnico);
        } else {
            Object[] mensaje = {"No hay resultados"};
            vista.notificar(mensaje);
        }
    }

    @Override
    public void cargar() {
        //El try catch Captura el error que se genera cuando 
        //la tabla de tecnicos esta vacia en la base de datos
        try {
            vista.mostrar(dao.listar());
        } catch (NullPointerException e) {
        }
    }

}
