package Dao;

import BaseDatos.BaseDatos;
import Modelo.Usuario;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.sql.Date;

/**
 *
 * @author Alvarado Ruiz
 */
public class UsuarioDao implements Dao<Usuario> {

    private BaseDatos db;

    public UsuarioDao(BaseDatos db) {
        this.db = db;
    }

    @Override
    public boolean insertar(Usuario usuario) {
        this.db.prepararSentencia("Insert into usuarios values (?,?,?,?,?,?,?,?)");
        Object[] param = {usuario.getCedula(), usuario.getNombreCompleto(), usuario.getFechaNacimiento(), usuario.getTelefono(),
            usuario.getCorreoElectronico(), usuario.getNombreUsuario(), usuario.getContrasenia(), usuario.getTipoUsuario()};
        return this.db.ejecutar(param);
    }

    @Override
    public boolean modificar(Usuario usuario) {
        this.db.prepararSentencia("Update usuarios set nombre=? where codigo=?");
        Object[] param = {usuario.getCedula(), usuario.getNombreCompleto(), usuario.getFechaNacimiento(), usuario.getTelefono(),
            usuario.getCorreoElectronico(), usuario.getNombreUsuario(), usuario.getContrasenia(), usuario.getTipoUsuario()};
        return this.db.ejecutar(param);
    }

    @Override
    public boolean eliminar(Usuario usuario) {
        this.db.prepararSentencia("Delete from usuarios where codigo=?");
        Object[] param = {usuario.getCedula()};
        return this.db.ejecutar(param);
    }

    //Busca un usuario en base a su nombre de usuario y devuelve la contraseña de ese usuario
    public String buscarUsuario(Usuario usuario) {
        this.db.prepararSentencia("Select * from usuarios where NombreUsuario=?");
        Object[] param = {usuario.getNombreUsuario()};
        Object[][] valores;
        valores = this.db.seleccionar(param);
        if (valores.length > 0) {
            Usuario user = new Usuario((int) valores[0][0], String.valueOf(valores[0][1]), fecha(String.valueOf(valores[0][2])),
                    (int) valores[0][3], String.valueOf(valores[0][4]), String.valueOf(valores[0][5]),
                    String.valueOf(valores[0][6]), String.valueOf(valores[0][7]));
            return user.getContrasenia();
        } else {
            return null;
        }
    }

    public Date fecha(String fecha) {
        try {
            SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy");
            java.util.Date parsed;
            parsed = format.parse(fecha);
            java.sql.Date sql = new java.sql.Date(parsed.getTime());
            return sql;
        } catch (ParseException ex) {
            return null;
        }
    }

    @Override
    public Usuario[] listar() {
        this.db.prepararSentencia("Select * from usuarios order by codigo");
        Object[] param = {};
        Object[][] valores;
        valores = this.db.seleccionar(param);
        if (valores.length > 0) {
            Usuario[] usuario = new Usuario[valores.length];
            for (int f = 0; f < valores.length; f++) {
                //usuario[f] = new Usuario((int) valores[f][0], String.valueOf(valores[f][1]), (int) valores[f][2]);
            }
            return usuario;
        } else {
            return null;
        }
    }

    @Override
    public boolean validarPk(Usuario distrito) {
        return false;
    }

    @Override
    public boolean validarFk(Usuario distrito) {
        return true;
    }

    @Override
    public boolean validarUnicos(Usuario ob) {
        return false;

    }

    @Override
    public Usuario buscar(Usuario ob) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
