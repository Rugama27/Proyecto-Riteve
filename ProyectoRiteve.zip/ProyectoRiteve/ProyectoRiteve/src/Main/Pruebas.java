package Main;

import BaseDatos.MariaDB;
import Dao.UsuarioDao;
import Modelo.Usuario;

/**
 *
 * @author Alvarado Ruiz
 */
public class Pruebas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MariaDB mariadb = new MariaDB("127.0.0.1", "dbriteve", "root", "");
        Usuario usuario = new Usuario("dfd");
        UsuarioDao uDao = new UsuarioDao(mariadb);
        System.out.println(uDao.buscarUsuario(usuario));
    }

}
