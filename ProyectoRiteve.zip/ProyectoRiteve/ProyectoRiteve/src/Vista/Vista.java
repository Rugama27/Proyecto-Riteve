package Vista;

/**
 *
 * @author Alvarado Ruiz
 */
public interface Vista {

    public void notificar(Object[] valores);

}
