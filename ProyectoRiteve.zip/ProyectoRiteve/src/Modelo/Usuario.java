package Modelo;

import java.sql.*;

/**
 *
 * @author Alvarado Ruiz
 */
public class Usuario {

    private int cedula;
    private String nombreCompleto;
    private Date fechaNacimiento;
    private int telefono;
    private String correoElectronico;
    private String nombreUsuario;
    private String contraseña;
    private String tipoUsuario;

    public int getCedula() {
        return cedula;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public Date getFechaNacimiento() {
        return fechaNacimiento;
    }

    public int getTelefono() {
        return telefono;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public String getContraseña() {
        return contraseña;
    }

    public String getTipoUsuario() {
        return tipoUsuario;
    }

    public Usuario(int cedula, String nombreCompleto, Date fechaNacimiento, int telefono, String correoElectronico, String nombreUsuario, String contraseña, String tipoUsuario) {
        this.cedula = cedula;
        this.nombreCompleto = nombreCompleto;
        this.fechaNacimiento = fechaNacimiento;
        this.telefono = telefono;
        this.correoElectronico = correoElectronico;
        this.nombreUsuario = nombreUsuario;
        this.contraseña = contraseña;
        this.tipoUsuario = tipoUsuario;
    }

    public Usuario() {
        this(0, null, null, 0, null, null, null, null);
    }

}
