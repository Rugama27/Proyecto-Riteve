package Modelo;

import java.sql.*;

/**
 *
 * @author Alvarado Ruiz
 */
public class Usuario {

    private int cedula;
    private String nombreCompleto;
    private Date fechaNacimiento;
    private int telefono;
    private String correoElectronico;
    private String nombreUsuario;
    private String contrasenia;
    private String tipoUsuario;

    public int getCedula() {
        return cedula;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public Date getFechaNacimiento() {
        return fechaNacimiento;
    }

    public int getTelefono() {
        return telefono;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public String getContrasenia() {
        return contrasenia;
    }

    public String getTipoUsuario() {
        return tipoUsuario;
    }

    public Usuario(int cedula, String nombreCompleto, Date fechaNacimiento, int telefono, String correoElectronico, String nombreUsuario, String contrasenia, String tipoUsuario) {
        this.cedula = cedula;
        this.nombreCompleto = nombreCompleto;
        this.fechaNacimiento = fechaNacimiento;
        this.telefono = telefono;
        this.correoElectronico = correoElectronico;
        this.nombreUsuario = nombreUsuario;
        this.contrasenia = contrasenia;
        this.tipoUsuario = tipoUsuario;
    }

    public Usuario() {
        this(0, null, null, 0, null, null, null, null);
    }
    
    
    public Usuario(String nombreUsuario) {
        this(0, null, null, 0, null, nombreUsuario, null, null);
    }

    @Override
    public String toString() {
        return "Usuario{" + "cedula=" + cedula + ", nombreCompleto=" + nombreCompleto + ", fechaNacimiento=" + fechaNacimiento + ", telefono=" + telefono + ", correoElectronico=" + correoElectronico + ", nombreUsuario=" + nombreUsuario + ", contrasenia=" + contrasenia + ", tipoUsuario=" + tipoUsuario + '}';
    }
    
    

}
