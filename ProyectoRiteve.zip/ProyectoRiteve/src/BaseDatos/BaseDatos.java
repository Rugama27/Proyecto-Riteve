package BaseDatos;

import java.sql.*;

/**
 *
 * @author Alvarado Ruiz
 */
public class BaseDatos {

    private String drive;
    private String api;
    private String motor;
    private String servidor;
    private String base;
    private String usuario;
    private String contraseña;
    private String error;

    public String getError() {
        return error;
    }

    private Connection conexion;
    private PreparedStatement sentencia;
    private ResultSet datos;

    public BaseDatos(String drive, String api, String motor, String servidor, String base, String usuario, String contraseña) {
        this.drive = drive;
        this.api = api;
        this.motor = motor;
        this.servidor = servidor;
        this.base = base;
        this.usuario = usuario;
        this.contraseña = contraseña;
        if (!this.conectar()) {
            throw new NullPointerException();
        }

    }

    private boolean conectar() {
        this.error = null;
        try {
            Class.forName(this.drive);
            this.conexion = DriverManager.getConnection(this.api + ":" + this.motor + "://"
                    + this.servidor + "/" + this.base, this.usuario, this.contraseña);
            return true;
        } catch (ClassNotFoundException | SQLException ex) {
            this.error = ex.toString();
            return false;
        }
    }

    public boolean prepararSentencia(String sql) {
        this.error = null;
        try {
            this.sentencia = this.conexion.prepareStatement(sql, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            return true;
        } catch (SQLException ex) {
            this.error = ex.toString();
            return false;
        }
    }

    public Object[][] seleccionar(Object[] parametros) {
        this.error = null;
        try {
            this.cargar(parametros);
            this.datos = this.sentencia.executeQuery();
            return this.toArray(this.datos);
        } catch (SQLException ex) {
            this.error = ex.toString();
            return null;
        }
    }

    public boolean ejecutar(Object[] parametros) {
        this.error = null;
        try {
            this.cargar(parametros);
            return this.sentencia.executeUpdate() > 0;
        } catch (SQLException ex) {
            this.error = ex.toString();
            return false;
        }
    }

    private void cargar(Object[] parametros) throws SQLException {
        int i = 1;
        for (Object parametro : parametros) {
            if (parametro instanceof Integer) {
                this.sentencia.setInt(i, (int) parametro);
            }
            if (parametro instanceof Double) {
                this.sentencia.setDouble(i, (Double) parametro);
            }
            if (parametro instanceof String) {
                this.sentencia.setString(i, (String) parametro);
            }
            if (parametro instanceof Date) {
                this.sentencia.setDate(i, (Date) parametro);
            }
            i++;
        }
    }

    public Object[][] toArray(ResultSet rs) throws SQLException {
        rs.last();
        Object[][] datos = new Object[rs.getRow()][rs.getMetaData().getColumnCount()];
        rs.beforeFirst();
        int f = 0;
        while (rs.next()) {
            for (int c = 0; c < rs.getMetaData().getColumnCount(); c++) {
                datos[f][c] = rs.getObject(c + 1);
            }
            f++;
        }
        return datos;
    }
}
