package Dao;

/**
 *
 * @author Alvarado Ruiz
 * @param <Clase>
 */
public interface Dao<Clase> {

    public boolean insertar(Clase ob);

    public boolean modificar(Clase ob);

    public boolean eliminar(Clase ob);

    public Clase buscar(Clase ob);

    public Clase[] listar();

    public boolean validarPk(Clase ob);

    public boolean validarFk(Clase ob);
    
    public boolean validarUnicos(Clase ob);
}
