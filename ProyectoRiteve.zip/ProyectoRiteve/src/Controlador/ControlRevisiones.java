/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import BaseDatos.MariaDB;
import Dao.RevisionDao;
import Modelo.Revision;
import Vista.Vista;

/**
 *
 * @author Erick Zúñiga
 */
public class ControlRevisiones implements Control<Revision>{
    private Vista vista;
    private MariaDB bd;
    private RevisionDao dao;

    public ControlRevisiones(Vista vista) {
        this.vista = vista;
        this.bd = new MariaDB("127.0.0.1", "dbriteve", "root", "");
        this.dao = new RevisionDao(this.bd);
    }

    @Override
    public void guardar(Revision revision) {
        if (dao.validarPk(revision)) {
            if (dao.insertar(revision)) {
                Object[] mensaje = {"La revision se registro con existo"};
                vista.notificar(mensaje);
                vista.cerrarVentana();
            } else {
                Object[] mensaje = {"Error al registrar"};
                vista.notificar(mensaje);
            }
        } else {
            Object[] mensaje = {"Error al registrar\nEl Id " + revision.getId()+ " ya exsite."};
            vista.notificar(mensaje);
        }
    }

    @Override
    public void modificar(Revision revision, String id) {
        if (dao.modificar(revision, id)) {
            Object[] mensaje = {"Revision modificada"};
            vista.notificar(mensaje);
            vista.cerrarVentana();
        } else {
            Object[] mensaje = {"Error al modificar"};
            vista.notificar(mensaje);
        }
    }

    @Override
    public void eliminar(Revision revision) {
        if (dao.eliminar(revision)) {
            Object[] mensaje = {"Revision eliminada"};
            vista.notificar(mensaje);
        } else {
            Object[] mensaje = {"Error al eliminar"};
            vista.notificar(mensaje);
        }
    }

    @Override
    public void cancelar() {
        vista.cerrarVentana();
    }

    @Override
    public void filtrar(String busqueda) {
        Revision[] vehiculo = this.dao.filtrar(busqueda);
        if (vehiculo != null) {
            vista.mostrar(vehiculo);
        } else {
            Object[] mensaje = {"No hay resultados"};
            vista.notificar(mensaje);
        }
    }

    @Override
    public void cargar() {
       vista.mostrar(dao.listar());
    }
}
