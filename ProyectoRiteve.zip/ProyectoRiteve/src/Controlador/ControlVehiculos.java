/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import BaseDatos.MariaDB;
import Dao.VehiculoDao;
import Modelo.Vehiculo;
import Vista.Vista;

/**
 *
 * @author Erick Zúñiga
 */
public class ControlVehiculos implements Control<Vehiculo>{
    
    private Vista vista;
    private MariaDB bd;
    private VehiculoDao dao;

    public ControlVehiculos(Vista vista) {
        this.vista = vista;
        this.bd = new MariaDB("127.0.0.1", "dbriteve", "root", "");
        this.dao = new VehiculoDao(this.bd);
    }

    @Override
    public void guardar(Vehiculo vehiculo) {
        if (dao.validarPk(vehiculo)) {
            if (dao.insertar(vehiculo)) {
                Object[] mensaje = {"El vehículo se registro con existo"};
                vista.notificar(mensaje);
                vista.cerrarVentana();
            } else {
                Object[] mensaje = {"Error al registrar"};
                vista.notificar(mensaje);
            }
        } else {
            Object[] mensaje = {"Error al registrar\nLa placa " + vehiculo.getPlaca() + " ya exsite."};
            vista.notificar(mensaje);
        }
    }

    @Override
    public void modificar(Vehiculo vehiculo, String placa) {
        if (dao.modificar(vehiculo, placa)) {
            Object[] mensaje = {"Vehículo modificado"};
            vista.notificar(mensaje);
            vista.cerrarVentana();
        } else {
            Object[] mensaje = {"Error al modificar"};
            vista.notificar(mensaje);
        }
    }

    @Override
    public void eliminar(Vehiculo vehiculo) {
        if (dao.eliminar(vehiculo)) {
            Object[] mensaje = {"Vehiculo eliminado"};
            vista.notificar(mensaje);
        } else {
            Object[] mensaje = {"Error al eliminar"};
            vista.notificar(mensaje);
        }
    }

    @Override
    public void cancelar() {
        vista.cerrarVentana();
    }

    @Override
    public void filtrar(String busqueda) {
        Vehiculo[] vehiculo = this.dao.filtrar(busqueda);
        if (vehiculo != null) {
            vista.mostrar(vehiculo);
        } else {
            Object[] mensaje = {"No hay resultados"};
            vista.notificar(mensaje);
        }
    }

    @Override
    public void cargar() {
        vista.mostrar(dao.listar());
    }
}
