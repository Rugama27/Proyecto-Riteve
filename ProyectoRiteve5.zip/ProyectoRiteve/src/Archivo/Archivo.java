package Archivo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Date;

/**
 *
 * @author Alvarado Ruiz
 */
public class Archivo {

    private File f;
    private FileReader fr;
    private FileWriter fw;
    private BufferedReader br;
    private BufferedWriter bw;

    public Archivo(String ruta) throws IOException {
        f = new File(ruta);
        if (validar()) {
            if (!existe()) {
                crear();
            }
        }
    }

    private boolean validar() {
        return f.isFile();
    }

    private boolean existe() {
        return f.exists();
    }

    private void crear() throws IOException {
        f.createNewFile();
    }

    public void eliminar() {
        if (existe()) {
            f.delete();
        }
    }

    public void abrir() throws FileNotFoundException, IOException {
        //Charset.forName("ISO-8859-1") es formato en español para el texto
        fr = new FileReader(f, Charset.forName("ISO-8859-1"));
        fw = new FileWriter(f, true);
        br = new BufferedReader(fr);
        bw = new BufferedWriter(fw);
    }

    public void cerrar() throws FileNotFoundException, IOException {
        br.close();
        bw.close();
        fr.close();
        fw.close();
    }

    public String leer() throws IOException {
        return br.readLine();
    }

    public void escribir(String texto) throws IOException {
        abrir();
        bw.write(texto);
    }

    public void guardar() throws IOException {
        bw.flush();
    }

    public void getCantidadLinias() throws IOException {
        br.lines().count();
    }

    public long getTamanio() {
        long tamañoBytes = f.length();
        long tamañoKiloBytes = tamañoBytes / 1024;
        long tamañoMegaBytes = tamañoKiloBytes / 1024;
        return tamañoMegaBytes;
    }

    public Date geFechaModificaciono() {
        return new Date(f.lastModified());
    }

}
