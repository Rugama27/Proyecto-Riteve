package Hilos;

import javax.swing.JDialog;
import javax.swing.JLabel;

/**
 *
 * @author Alvarado Ruiz
 */
public class AnimacionCarga extends Thread {

    JLabel circulo1, circulo2, circulo3;
    int cont = 0;
    JDialog vista;

    public AnimacionCarga(JLabel circulo1, JLabel circulo2,
            JLabel circulo3, JDialog vista) {
        this.circulo1 = circulo1;
        this.circulo2 = circulo2;
        this.circulo3 = circulo3;
        this.vista = vista;
    }

    @Override
    public void run() {
        for (int i = 0; i <= 30; i++) {
            try {
                cont++;

                if (cont == 1) {
                    circulo1.setEnabled(true);
                    circulo2.setEnabled(false);
                    circulo3.setEnabled(false);
                }

                if (cont == 5) {
                    circulo1.setEnabled(false);
                    circulo2.setEnabled(true);
                    circulo3.setEnabled(false);
                }

                if (cont == 10) {
                    circulo1.setEnabled(false);
                    circulo2.setEnabled(false);
                    circulo3.setEnabled(true);
                }

                if (cont == 15) {
                    cont = 0;
                }

                Thread.sleep(100);
            } catch (InterruptedException ex) {
            }
        }
        circulo1.setEnabled(false);
        circulo2.setEnabled(false);
        circulo3.setEnabled(false);
        vista.dispose();
    }

}
