package Dao;

import BaseDatos.BaseDatos;
import Modelo.Cita;
import Modelo.Revision;
import Modelo.Tecnico;
import Modelo.Vehiculo;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.sql.Date;

/**
 *
 * @author Erick Zuñiga
 */
public class RevisionDao implements Dao<Revision> {

    private BaseDatos db;

    public RevisionDao(BaseDatos db) {
        this.db = db;
    }

    @Override
    public boolean insertar(Revision revision) {
        this.db.prepararSentencia("Insert into revisiones (Fecha, Hora, Tecnico, TipoRevision, Observaciones, Estado, Cita) "
                + "values (?,?,?,?,?,?,?)");
        Object[] param = {revision.getFecha(), revision.getHora(), revision.getTecnico().getCedula(),
            revision.getTipoRevision(), revision.getObservaciones(), revision.getEstado(), revision.getCita().getId()};
        return this.db.ejecutar(param);
    }

    public boolean modificar(Revision revision) {
        this.db.prepararSentencia("Update revisiones set Tecnico=?, TipoRevision=?, Observaciones=?, Estado=? where IdRevision=?");
        Object[] param = {revision.getTecnico().getCedula(), revision.getTipoRevision(), revision.getObservaciones(),
            revision.getEstado(), revision.getId()};
        return this.db.ejecutar(param);
    }

    @Override
    public boolean eliminar(Revision revision) {
        this.db.prepararSentencia("Delete from revisiones where IdRevision=?");
        Object[] param = {revision.getId()};
        return this.db.ejecutar(param);
    }

    @Override
    public Revision buscar(Revision revision) {
        this.db.prepararSentencia("Select * from revisiones where IdRevision=?");
        Object[] param = {revision.getId()};
        Object[][] valores;
        valores = this.db.seleccionar(param);
        if (valores.length > 0) {
            int cedulaTecnico = (int) valores[0][3];
            int idCita = (int) valores[0][7];
            return new Revision((int) valores[0][0], fecha(String.valueOf(valores[0][1])), String.valueOf(valores[0][2]), buscarTecnico(cedulaTecnico),
                    String.valueOf(valores[0][4]), String.valueOf(valores[0][5]), String.valueOf(valores[0][6]), buscarCita(idCita));
        } else {
            return null;
        }
    }

    public Revision buscarPorCedula(Revision revision) {
        this.db.prepararSentencia("Select * from revisiones where IdRevision=?");
        Object[] param = {revision.getId()};
        Object[][] valores;
        valores = this.db.seleccionar(param);
        if (valores.length > 0) {
            int cedulaTecnico = (int) valores[0][3];
            int idCita = (int) valores[0][7];
            return new Revision((int) valores[0][0], fecha(String.valueOf(valores[0][1])), String.valueOf(valores[0][2]), buscarTecnico(cedulaTecnico),
                    String.valueOf(valores[0][4]), String.valueOf(valores[0][5]), String.valueOf(valores[0][6]), buscarCita(idCita));
        } else {
            return null;
        }
    }

    public Tecnico buscarTecnico(int cedula) {
        this.db.prepararSentencia("Select * from tecnicos where Cedula=?");
        Object[] param = {cedula};
        Object[][] valores;
        valores = this.db.seleccionar(param);
        if (valores.length > 0) {
            return new Tecnico((int) valores[0][0], String.valueOf(valores[0][1]), fecha(String.valueOf(valores[0][2])),
                    (int) valores[0][3], String.valueOf(valores[0][4]), (Double) valores[0][5]);
        } else {
            return null;
        }
    }

    public Cita buscarCita(int id) {
        this.db.prepararSentencia("Select * from citas where IdCitas=?");
        Object[] param = {id};
        Object[][] valores;
        valores = this.db.seleccionar(param);
        if (valores.length > 0) {
            String placaVehiculo = String.valueOf(valores[0][3]);
            return new Cita((int) valores[0][0], fecha(String.valueOf(valores[0][1])), (String.valueOf(valores[0][2])), buscarVehiculo(placaVehiculo));
        } else {
            return null;
        }
    }

    public Cita buscarCita(String placa) {
        this.db.prepararSentencia("Select * from citas where DatosVehiculo=?");
        Object[] param = {placa};
        Object[][] valores;
        valores = this.db.seleccionar(param);
        if (valores.length > 0) {
            String placaVehiculo = String.valueOf(valores[0][3]);
            return new Cita((int) valores[0][0], fecha(String.valueOf(valores[0][1])), (String.valueOf(valores[0][2])), buscarVehiculo(placaVehiculo));
        } else {
            return null;
        }
    }

    public Vehiculo buscarVehiculo(String placa) {
        this.db.prepararSentencia("Select * from vehiculos where Placa=?");
        Object[] param = {placa};
        Object[][] valores;
        valores = this.db.seleccionar(param);
        if (valores.length > 0) {
            return new Vehiculo(String.valueOf(valores[0][0]), String.valueOf(valores[0][1]), String.valueOf(valores[0][2]), (int) valores[0][3],
                    fecha(String.valueOf(valores[0][4])), (int) valores[0][5], String.valueOf(valores[0][6]));
        } else {
            return null;
        }
    }

    @Override
    public Revision[] listar() {
        this.db.prepararSentencia("Select * from revisiones order by IdRevision");
        Object[] param = {};
        Object[][] valores;
        valores = this.db.seleccionar(param);
        if (valores.length > 0) {
            Revision[] revision = new Revision[valores.length];
            for (int f = 0; f < valores.length; f++) {
                int cedulaTecnico = (int) valores[f][3];
                int idCita = (int) valores[f][7];
                revision[f] = new Revision((int) valores[f][0], fecha(String.valueOf(valores[f][1])), String.valueOf(valores[f][2]), buscarTecnico(cedulaTecnico),
                        String.valueOf(valores[f][4]), String.valueOf(valores[f][5]), String.valueOf(valores[f][6]), buscarCita(idCita));
            }
            return revision;
        } else {
            return null;
        }
    }

    public Date fecha(String fecha) {
        try {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            java.util.Date parsed;
            parsed = format.parse(fecha);
            java.sql.Date sql = new java.sql.Date(parsed.getTime());
            return sql;
        } catch (ParseException ex) {
            return null;
        }
    }

    @Override
    public Revision[] filtrar(String fecha) {
        this.db.prepararSentencia("Select * from revisiones where Fecha like (?) order by IdRevision");
        Object[] param = {fecha + "%"};
        Object[][] valores;
        valores = this.db.seleccionar(param);
        if (valores != null && valores.length > 0) {
            Revision[] revision = new Revision[valores.length];
            for (int f = 0; f < valores.length; f++) {
                int cedulaTecnico = (int) valores[f][3];
                int idCita = (int) valores[f][7];
                revision[f] = new Revision((int) valores[f][0], fecha(String.valueOf(valores[f][1])), String.valueOf(valores[f][2]), buscarTecnico(cedulaTecnico),
                        String.valueOf(valores[f][4]), String.valueOf(valores[f][5]), String.valueOf(valores[f][6]), buscarCita(idCita));
            }
            return revision;
        } else {
            return null;
        }
    }

    @Override
    public boolean validarPk(Revision revision) {
        revision = buscarPorCedula(revision);
        return revision == null;
    }

    public boolean validarFk(Revision revision) {
        TecnicoDao tecnicoDao = new TecnicoDao(this.db);
        return !tecnicoDao.validarPk(revision.getTecnico());
    }

    @Override
    public boolean modificar(Revision ob, String str) {
        return false;
    }

}
