package Controlador;

import Archivo.Archivo;
import BaseDatos.MariaDB;
import Dao.UsuarioDao;
import Modelo.Usuario;
import Vista.Vista;
import java.io.IOException;

/**
 *
 * @author Alvarado Ruiz
 */
public class ControlUsuarios implements Control<Usuario> {

    private Vista vista;
    private MariaDB bd;
    private UsuarioDao dao;

    public ControlUsuarios(Vista vista) {
        this.vista = vista;
        String servidor = (String) archivoConfigBD()[0];
        String baseDatos = (String) archivoConfigBD()[1];
        String usuario = (String) archivoConfigBD()[2];
        String contrasenia = (String) archivoConfigBD()[3];
        
        this.bd = new MariaDB(servidor, baseDatos, usuario, contrasenia);
        this.dao = new UsuarioDao(this.bd);
    }

    private Object[] archivoConfigBD() {
        Object[] configBD = new Object[4];
        try {
            Archivo archivo = new Archivo("C:\\configDB\\configDB.ini");
            String registro = archivo.leer();

            String[] datos = registro.split(",");
            configBD[0] = datos[0].strip();
            configBD[1] = datos[1].strip();
            configBD[2] = datos[2].strip();
            configBD[3] = datos[3].strip();

        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        return configBD;
    }

    @Override
    public void guardar(Usuario usuario) {
        if (dao.validarPk(usuario)) {
            if (dao.insertar(usuario)) {
                Object[] mensaje = {"Se registro con existo"};
                vista.notificar(mensaje);
                vista.cerrarVentana();
            } else {
                Object[] mensaje = {"Error al registrase"};
                vista.notificar(mensaje);
            }
        } else {
            Object[] mensaje = {"Error al registrase\nEl numero de cedula " + usuario.getCedula() + " ya existe."};
            vista.notificar(mensaje);
        }
    }

    @Override
    public void modificar(Usuario usuario, String cedula) {
        if (dao.modificar(usuario, cedula)) {
            Object[] mensaje = {"Registro modificado"};
            vista.notificar(mensaje);
            vista.cerrarVentana();
        } else {
            Object[] mensaje = {"Error al modificar"};
            vista.notificar(mensaje);
        }
    }

    @Override
    public void eliminar(Usuario usuario) {
        if (dao.eliminar(usuario)) {
            Object[] mensaje = {"Registro eliminado"};
            vista.notificar(mensaje);
        } else {
            Object[] mensaje = {"Error al eliminar"};
            vista.notificar(mensaje);
        }
    }

    @Override
    public void filtrar(String busqueda) {
        Usuario[] usuario = this.dao.filtrar(busqueda);
        if (usuario != null) {
            vista.mostrar(usuario);
        } else {
            Object[] mensaje = {"No hay resultados"};
            vista.notificar(mensaje);
        }
    }

    //Comprueba que la contraseña ingresada en Iniciar Sesion sea correcta
    public boolean validarLogin(Usuario usuario, String contrasenia) {
        if (dao.buscar(usuario) != null) {
            return dao.buscar(usuario).getContrasenia().equals(contrasenia);
        } else {
            return false;
        }
    }

    //Cancela el preceso de registro, se sale de la ventana actual.
    @Override
    public void cancelar() {
        vista.cerrarVentana();
    }

    //Carga la informacion de la base de datos.
    @Override
    public void cargar() {
        vista.mostrar(dao.listar());
    }

    @Override
    public Usuario buscar(Usuario clase) {
        return null;
    }

}
