/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Archivo.Archivo;
import BaseDatos.MariaDB;
import Dao.RevisionDao;
import Modelo.Cita;
import Modelo.Revision;
import Modelo.Tecnico;
import Vista.Vista;
import java.io.IOException;
import javax.swing.JOptionPane;

/**
 *
 * @author Erick Zúñiga
 */
public class ControlRevisiones implements Control<Revision> {

    private Vista vista;
    private MariaDB bd;
    private RevisionDao dao;

    public ControlRevisiones(Vista vista) {
        this.vista = vista;
        String servidor = (String) archivoConfigBD()[0];
        String baseDatos = (String) archivoConfigBD()[1];
        String usuario = (String) archivoConfigBD()[2];
        String contrasenia = (String) archivoConfigBD()[3];

        this.bd = new MariaDB(servidor, baseDatos, usuario, contrasenia);
        this.dao = new RevisionDao(this.bd);
    }

    private Object[] archivoConfigBD() {
        Object[] configBD = new Object[4];
        try {
            Archivo archivo = new Archivo("C:\\configDB\\configDB.ini");
            String registro = archivo.leer();

            String[] datos = registro.split(",");
            configBD[0] = datos[0].strip();
            configBD[1] = datos[1].strip();
            configBD[2] = datos[2].strip();
            configBD[3] = datos[3].strip();

        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        return configBD;
    }

    @Override
    public void guardar(Revision revision) {
        try {
            if (dao.validarPk(revision)) {
                if (dao.insertar(revision)) {
                    Object[] mensaje = {"La revision se registro con existo"};
                    vista.notificar(mensaje);
                    vista.cerrarVentana();
                } else {
                    Object[] mensaje = {"Error al registrar"};
                    vista.notificar(mensaje);
                    System.out.println(bd.getError());
                }
            } else {
                Object[] mensaje = {"Error al registrar\nEl Id " + revision.getId() + " ya existe."};
                vista.notificar(mensaje);
            }
        } catch (NullPointerException e) {
        }
    }

    public void modificarRevision(Revision revision) {
        if (dao.validarFk(revision)) {
            if (dao.modificar(revision)) {
                Object[] mensaje = {"Revision modificada"};
                vista.notificar(mensaje);
                vista.cerrarVentana();
            } else {
                Object[] mensaje = {"Error al modificar"};
                vista.notificar(mensaje);
                System.out.println(bd.getError());
            }
        } else {
            Object[] mensaje = {"Error al modificar\nLa cedula " + revision.getTecnico().getCedula() + " del tecnico no exite."};
            vista.notificar(mensaje);
        }

    }

    @Override
    public void eliminar(Revision revision
    ) {
        if (dao.eliminar(revision)) {
            Object[] mensaje = {"Revision eliminada"};
            vista.notificar(mensaje);
        } else {
            Object[] mensaje = {"Error al eliminar"};
            vista.notificar(mensaje);
        }
    }

    @Override
    public void cancelar() {
        vista.cerrarVentana();
    }

    @Override
    public void filtrar(String busqueda
    ) {
        Revision[] vehiculo = this.dao.filtrar(busqueda);
        if (vehiculo != null) {
            vista.mostrar(vehiculo);
        } else {
            Object[] mensaje = {"No hay resultados"};
            vista.notificar(mensaje);
        }
    }

    @Override
    public void cargar() {
        //El try catch Captura el error que se genera cuando 
        //la tabla de vehiculos esta vacia en la base de datos
        try {
            vista.mostrar(dao.listar());
        } catch (NullPointerException e) {
        }
    }

    public Tecnico buscarTecnico(int cedula) {
        if (dao.buscarTecnico(cedula) != null) {
            return dao.buscarTecnico(cedula);
        } else {
            Object[] mensaje = {"Tecnico no registrado"};
            vista.notificar(mensaje);
            return null;
        }
    }

    public Cita buscarCita(String placa) {
        if (dao.buscarCita(placa) != null) {
            return dao.buscarCita(placa);
        } else {
            Object[] mensaje = {"Cita no registrada"};
            vista.notificar(mensaje);
            return null;
        }
    }

    public void exportar(Revision revision) {
        try {
            Archivo carpeta = new Archivo("C:\\RevisionesExportadas");
            carpeta.crearCarpeta();
            Archivo archivo = new Archivo("C:\\RevisionesExportadas\\"
                    + "Revisiones (" + revision.getCita().getDatosVehiculo().getPlaca() + ").xml");
            archivo.crearArchivo();

            archivo.write("<Revisiones>");
            archivo.write("<id Revisión =\"" + revision.getId() + "\">");
            escribirDatosVehiculo(archivo, revision);
            archivo.write("<Fecha>" + revision.getFecha() + "</Fecha>");
            archivo.write("<Hora>" + revision.getFecha() + "</Hora>");
            escribirDatosTecnico(archivo, revision);
            archivo.write("<TipoRevision>" + revision.getTipoRevision() + "</TipoRevision>");
            archivo.write("<Observaciones>" + revision.getObservaciones() + "</Observaciones>");
            archivo.write("<Estado>" + revision.getEstado() + "</Estado>");
            archivo.write("</Revisiones>");
            archivo.cerrar();
            JOptionPane.showMessageDialog(null, "Se exportó con exito");

        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "Error al exportar");
        }
    }

    private void escribirDatosTecnico(Archivo archivo, Revision revision) throws IOException {
        archivo.write("<Tecnico>");
        archivo.write("<Cedula =\"" + revision.getTecnico().getCedula() + "\">");
        archivo.write("<NombreCompleto>" + revision.getTecnico().getNombreCompleto() + "</NombreCompleto>");
        archivo.write("<FechaNacimiento>" + revision.getTecnico().getFechaNacimiento() + "</FechaNacimiento>");
        archivo.write("<Telefono>" + revision.getTecnico().getTelefono() + "</Telefono>");
        archivo.write("<CorreoElectronico >" + revision.getTecnico().getCorreoElectronico() + "</CorreoElectronico >");
        archivo.write("<Salario>" + revision.getTecnico().getSalario() + "</Salario>");
        archivo.write("</Tecnico>");
    }

    private void escribirDatosVehiculo(Archivo archivo, Revision revision) throws IOException {
        archivo.write("<Vehiculo>");
        archivo.write("<Placa =\"" + revision.getCita().getDatosVehiculo().getPlaca() + "\">");
        archivo.write("<Marca>" + revision.getCita().getDatosVehiculo().getMarca() + "</Marca>");
        archivo.write("<Modelo>" + revision.getCita().getDatosVehiculo().getModelo() + "</Modelo>");
        archivo.write("<Año>" + revision.getCita().getDatosVehiculo().getAño() + "</Año>");
        archivo.write("<FechaInscripcion>" + revision.getCita().getDatosVehiculo().getFechaInscripcion() + "</FechaInscripcion>");
        archivo.write("<cedulaPropietario>" + revision.getCita().getDatosVehiculo().getCedulaPropietario() + "</cedulaPropietario>");
        archivo.write("<Propietario>" + revision.getCita().getDatosVehiculo().getPropietario() + "</Propietario>");
        archivo.write("</Vehiculo>");
    }

    @Override
    public Revision buscar(Revision clase) {
        return null;
    }

    @Override
    public void modificar(Revision clase, String str) {
    }
}
