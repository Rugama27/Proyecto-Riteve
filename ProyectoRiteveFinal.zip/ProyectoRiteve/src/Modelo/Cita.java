package Modelo;

import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author Erick Zúñiga
 */
public class Cita {

    private int id;
    private Date fecha;
    private String hora;
    private Vehiculo datosVehiculo;

    public Cita(int id, Date fecha, String hora, Vehiculo datosVehiculo) {
        this.id = id;
        this.fecha = fecha;
        this.hora = hora;
        this.datosVehiculo = datosVehiculo;
    }

    public Cita(Date fecha, String hora, Vehiculo datosVehiculo) {
        this.fecha = fecha;
        this.hora = hora;
        this.datosVehiculo = datosVehiculo;
    }

    public Cita() {
        this(0, null, null, null);
    }

    public Cita(int id) {
        this(id, null, null, null);
    }

    public int getId() {
        return id;
    }

    public Date getFecha() {
        return fecha;
    }

    public String getHora() {
        return hora;
    }

    public Vehiculo getDatosVehiculo() {
        return datosVehiculo;
    }

    public int anio() {
        String[] datoFecha;
        datoFecha = String.valueOf(fecha).split("-");
        return Integer.parseInt(datoFecha[0]);
    }

    public int mes() {
        String[] datoFecha;
        datoFecha = String.valueOf(fecha).split("-");
        return Integer.parseInt(datoFecha[1]);
    }

    public int dia() {
        String[] datoFecha;
        datoFecha = String.valueOf(fecha).split("-");
        return Integer.parseInt(datoFecha[2]);
    }

    public int hora() {
        String[] datoHora;
        datoHora = hora.split(":");
        return Integer.parseInt(datoHora[0]);
    }

    public int anioActual() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy");
        return Integer.parseInt(dtf.format(LocalDateTime.now()));
    }

    public int mesActual() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM");
        return Integer.parseInt(dtf.format(LocalDateTime.now()));
    }

    public int diaActual() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd");
        return Integer.parseInt(dtf.format(LocalDateTime.now()));
    }

    public int horaActual() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH");
        return Integer.parseInt(dtf.format(LocalDateTime.now()));
    }
}
