package Vista;

/**
 *
 * @author Alvarado Ruiz
 */
public interface Vista {

    public void notificar(Object[] valores);

    public void mostrar(Object[] valores);

    public void cerrarVentana();

    public boolean verificar(Object[] valores);

}
