package Vista.GestionRevisiones;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author Alvarado Ruiz
 */
public class fechaActual {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        DateTimeFormatter dtfFecha = DateTimeFormatter.ofPattern("yyyy/MM/dd");
        DateTimeFormatter dtfHora = DateTimeFormatter.ofPattern("HH");
        String fechaActual = dtfFecha.format(LocalDateTime.now());
        String HoraActual = dtfHora.format(LocalDateTime.now());
        System.out.println(fechaActual);
        System.out.println(HoraActual);
    }

}
