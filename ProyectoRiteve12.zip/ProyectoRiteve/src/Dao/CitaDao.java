package Dao;

import BaseDatos.BaseDatos;
import Modelo.Cita;
import Modelo.Vehiculo;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 *
 * @author Luis Rugama
 */
public class CitaDao implements Dao<Cita> {

    private BaseDatos db;

    public CitaDao(BaseDatos db) {
        this.db = db;
    }

    @Override
    public boolean insertar(Cita cita) {
        insertarVehiculo(cita.getDatosVehiculo());
        this.db.prepararSentencia("Insert into citas (Fecha, Hora, DatosVehiculo) values (?,?,?)");
        Object[] param = {cita.getFecha(), cita.getHora(), cita.getDatosVehiculo().getPlaca()};
        return this.db.ejecutar(param);
    }

    //Inserta el vehiculo cuando no esta registrado antes de insertar la informacion de la cita
    //Para evitar restricciones de la llave foranea porque el vehiculo no exista
    public boolean insertarVehiculo(Vehiculo vehiculo) {
        this.db.prepararSentencia("Insert into vehiculos values (?,?,?,?,?,?,?)");
        Object[] param = {vehiculo.getPlaca(), vehiculo.getMarca(), vehiculo.getModelo(), vehiculo.getAño(),
            vehiculo.getFechaInscripcion(), vehiculo.getCedulaPropietario(), vehiculo.getPropietario()};
        return this.db.ejecutar(param);
    }

    public boolean modificar(Cita cita) {
        this.db.prepararSentencia("Update citas set Fecha=?, Hora=?, DatosVehiculo=? where IdCitas=?");
        Object[] param = {cita.getFecha(), cita.getHora(), cita.getDatosVehiculo().getPlaca(), cita.getId()};
        return this.db.ejecutar(param);
    }

    @Override
    public boolean eliminar(Cita citas) {
        this.db.prepararSentencia("Delete from citas where IdCitas=?");
        Object[] param = {citas.getId()};
        return this.db.ejecutar(param);
    }

    @Override
    public Cita buscar(Cita citas) {
        this.db.prepararSentencia("Select * from citas where IdCitas=?");
        Object[] param = {citas.getId()};
        Object[][] valores;
        valores = this.db.seleccionar(param);
        if (valores.length > 0) {
            String placaVehiculo = String.valueOf(valores[0][3]);
            return new Cita((int) valores[0][0], fecha(String.valueOf(valores[0][1])), (String.valueOf(valores[0][2])), buscarVehiculo(placaVehiculo));
        } else {
            return null;
        }
    }

    public Cita buscarCitaPlaca(Cita citas) {
        this.db.prepararSentencia("Select * from citas where DatosVehiculo=?");
        Object[] param = {citas.getDatosVehiculo().getPlaca()};
        Object[][] valores;
        valores = this.db.seleccionar(param);
        if (valores.length > 0) {
            String placaVehiculo = String.valueOf(valores[0][3]);
            return new Cita((int) valores[0][0], fecha(String.valueOf(valores[0][1])), (String.valueOf(valores[0][2])), buscarVehiculo(placaVehiculo));
        } else {
            return null;
        }
    }

    public Vehiculo buscarVehiculo(String placa) {
        this.db.prepararSentencia("Select * from vehiculos where Placa=?");
        Object[] param = {placa};
        Object[][] valores;
        valores = this.db.seleccionar(param);
        if (valores.length > 0) {
            return new Vehiculo(String.valueOf(valores[0][0]), String.valueOf(valores[0][1]), String.valueOf(valores[0][2]), (int) valores[0][3],
                    fecha(String.valueOf(valores[0][4])), (int) valores[0][5], String.valueOf(valores[0][6]));
        } else {
            return null;
        }
    }

    @Override
    public Cita[] listar() {
        this.db.prepararSentencia("Select * from citas order by IdCitas");
        Object[] param = {};
        Object[][] valores;
        valores = this.db.seleccionar(param);
        if (valores.length > 0) {
            Cita[] cita = new Cita[valores.length];
            for (int f = 0; f < valores.length; f++) {
                String placaVehiculo = String.valueOf(valores[f][3]);
                cita[f] = new Cita((int) valores[f][0], fecha(String.valueOf(valores[f][1])), (String.valueOf(valores[f][2])), buscarVehiculo(placaVehiculo));
            }
            return cita;
        } else {
            return null;
        }
    }

    public Date fecha(String fecha) {
        try {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            java.util.Date parsed;
            parsed = format.parse(fecha);
            java.sql.Date sql = new java.sql.Date(parsed.getTime());
            return sql;
        } catch (ParseException ex) {
            return null;
        }
    }

    @Override
    public Cita[] filtrar(String nombre) {
        this.db.prepararSentencia("Select * from citas where DatosVehiculo like (?) order by IdCitas");
        Object[] param = {nombre + "%"};
        Object[][] valores;
        valores = this.db.seleccionar(param);
        if (valores != null && valores.length > 0) {
            Cita[] cita = new Cita[valores.length];
            for (int f = 0; f < valores.length; f++) {
                String placaVehiculo = String.valueOf(valores[f][3]);
                cita[f] = new Cita((int) valores[f][0], fecha(String.valueOf(valores[f][1])), (String.valueOf(valores[f][2])), buscarVehiculo(placaVehiculo));
            }
            return cita;
        } else {
            return null;
        }
    }

    @Override
    public boolean validarPk(Cita cita) {
        cita = buscar(cita);
        return cita == null;
    }

    @Override
    public boolean modificar(Cita ob, String str) {
        return false;
    }

    public boolean validarFk(Cita cita) {
        VehiculoDao vehiculoDao = new VehiculoDao(this.db);
        return !vehiculoDao.validarPk(cita.getDatosVehiculo());
    }

}
