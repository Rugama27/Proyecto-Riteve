package Dao;

import BaseDatos.BaseDatos;
import Modelo.Revision;
import Modelo.Tecnico;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.sql.Date;

/**
 *
 * @author Erick Zuñiga
 */
public class RevisionDao implements Dao<Revision> {

    private BaseDatos db;

    public RevisionDao(BaseDatos db) {
        this.db = db;
    }

    @Override
    public boolean insertar(Revision revision) {
        this.db.prepararSentencia("Insert into revisiones values (?,?,?,?,?,?,?,?)");
        Object[] param = {revision.getFecha(), revision.getHora(), revision.getTecnico(),
            revision.getTipoRevision(), revision.getObservaciones(), revision.getEstado(), revision.getId()};
        return this.db.ejecutar(param);
    }

    @Override
    public boolean modificar(Revision revision, String Id) {

        this.db.prepararSentencia("Update revisiones set Fecha=?, Hora=?, Tecnico=?, "
                + "TipoRevision=?, Observaciones=?, Esado=?, IdRevision=? where Id=?");
        Object[] param = {revision.getFecha(), revision.getHora(), revision.getTecnico(),
            revision.getTipoRevision(), revision.getObservaciones(), revision.getEstado(), revision.getId(), revision.getId()};
        return this.db.ejecutar(param);
    }

    @Override
    public boolean eliminar(Revision revision) {
        this.db.prepararSentencia("Delete from revisiones where IdRevision=?");
        Object[] param = {revision.getId()};
        return this.db.ejecutar(param);
    }

    @Override
    public Revision buscar(Revision revision) {
        this.db.prepararSentencia("Select * from revisiones where IdRevision=?");
        Object[] param = {revision.getId()};
        Object[][] valores;
        valores = this.db.seleccionar(param);
        if (valores.length > 0) {
            return new Revision(fecha(String.valueOf(valores[0][0])), String.valueOf(valores[0][1]), (Tecnico) valores[0][2],
                    String.valueOf(valores[0][4]), String.valueOf(valores[0][5]), String.valueOf(valores[0][6]), (int) valores[0][3]);
        } else {
            return null;
        }
    }

    public Revision buscarPorCedula(Revision revision) {
        this.db.prepararSentencia("Select * from revisiones where IdRevision=?");
        Object[] param = {revision.getId()};
        Object[][] valores;
        valores = this.db.seleccionar(param);
        if (valores.length > 0) {
            return new Revision(fecha(String.valueOf(valores[0][0])), String.valueOf(valores[0][1]), (Tecnico) valores[0][2],
                    String.valueOf(valores[0][4]), String.valueOf(valores[0][5]), String.valueOf(valores[0][6]), (int) valores[0][3]);
        } else {
            return null;
        }
    }

    @Override
    public Revision[] listar() {
        this.db.prepararSentencia("Select * from revisiones order by IdRevision");
        Object[] param = {};
        Object[][] valores;
        valores = this.db.seleccionar(param);
        if (valores.length > 0) {
            Revision[] usuario = new Revision[valores.length];
            for (int f = 0; f < valores.length; f++) {
                usuario[f] = new Revision(fecha(String.valueOf(valores[f][0])), String.valueOf(valores[f][1]), (Tecnico) valores[f][2],
                String.valueOf(valores[f][4]), String.valueOf(valores[f][5]), String.valueOf(valores[f][6]), (int) valores[f][3]);
            }
            return usuario;
        } else {
            return null;
        }
    }

    public Date fecha(String fecha) {
        try {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            java.util.Date parsed;
            parsed = format.parse(fecha);
            java.sql.Date sql = new java.sql.Date(parsed.getTime());
            return sql;
        } catch (ParseException ex) {
            return null;
        }
    }
//Revisar esto
    @Override
    public Revision[] filtrar(String nombre) {
        this.db.prepararSentencia("Select * from revisiones where IdRevision like (?) order by IdRevision");
        Object[] param = {nombre + "%"};
        Object[][] valores;
        valores = this.db.seleccionar(param);
        if (valores != null && valores.length > 0) {
            Revision[] usuario = new Revision[valores.length];
            for (int f = 0; f < valores.length; f++) {
                usuario[f] = new Revision(fecha(String.valueOf(valores[f][0])), String.valueOf(valores[f][1]), (Tecnico) valores[f][2],
                String.valueOf(valores[f][4]), String.valueOf(valores[f][5]), String.valueOf(valores[f][6]), (int) valores[f][3]);
            }
            return usuario;
        } else {
            return null;
        }
    }

    @Override
    public boolean validarPk(Revision revision) {
        revision = buscarPorCedula(revision);
        return revision == null;
    }

}
