package Modelo;

import java.sql.*;

/**
 *
 * @author Alvarado Ruiz
 */
public class Vehiculo {
    private String placa;
    private String marca;
    private String modelo;
    private Date año;
    private Date fechaInscripcion;
    private int cedulaPropietario;
    private String propietario;

    public String getPlaca() {
        return placa;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public Date getAño() {
        return año;
    }

    public Date getFechaInscripcion() {
        return fechaInscripcion;
    }

    public int getCedulaPropietario() {
        return cedulaPropietario;
    }

    public String getPropietario() {
        return propietario;
    }

    public Vehiculo(String placa, String marca, String modelo, Date año, Date fechaInscripcion, int cedulaPropietario, String propietario) {
        this.placa = placa;
        this.marca = marca;
        this.modelo = modelo;
        this.año = año;
        this.fechaInscripcion = fechaInscripcion;
        this.cedulaPropietario = cedulaPropietario;
        this.propietario = propietario;
    }

    public Vehiculo() {
        this(null, null, null, null, null, 0, null);
    }
}
