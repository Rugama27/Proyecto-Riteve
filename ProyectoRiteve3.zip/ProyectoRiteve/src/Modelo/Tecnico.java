package Modelo;

import java.sql.*;

/**
 *
 * @author Luis Rugama
 */
public class Tecnico {
    private int cedula;
    private String nombreCompleto;
    private Date date;
    private int telefono;
    private String correoElectronico;
    private int salario;

    public Tecnico(int cedula, String nombreCompleto, Date date, int telefono, String correoElectronico, int salario) {
        this.cedula = cedula;
        this.nombreCompleto = nombreCompleto;
        this.date = date;
        this.telefono = telefono;
        this.correoElectronico = correoElectronico;
        this.salario = salario;
    }
    public Tecnico() {
        this(0, null,null,0,null,0);
    }

    public int getCedula() {
        return cedula;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public Date getDate() {
        return date;
    }

    public int getTelefono() {
        return telefono;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public int getSalario() {
        return salario;
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
}
