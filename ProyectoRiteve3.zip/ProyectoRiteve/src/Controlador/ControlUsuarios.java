package Controlador;

import BaseDatos.MariaDB;
import Dao.UsuarioDao;
import Modelo.Usuario;
import Vista.Vista;

/**
 *
 * @author Alvarado Ruiz
 */
public class ControlUsuarios implements Control<Usuario> {

    private Usuario usuario;
    private Vista vista;
    private MariaDB bd;
    private UsuarioDao dao;

    public ControlUsuarios(Vista vista) {
        this.vista = vista;
        this.usuario = new Usuario();
        this.bd = new MariaDB("127.0.0.1", "dbriteve", "root", "");
        this.dao = new UsuarioDao(this.bd);
    }

    @Override
    public void guardar(Usuario usuario) {
        if (dao.insertar(usuario)) {
            this.usuario = usuario;
            Object[] mensaje = {"Se registro con existo"};
            vista.notificar(mensaje);
        } else {
            Object[] mensaje = {"Error al registrase"};
            vista.notificar(mensaje);
        }
    }

    public boolean validarContraseña(Usuario usuario, String contrasenia) {
        if (dao.buscar(usuario) != null) {
            return dao.buscar(usuario).getContrasenia().equals(contrasenia);
        } else {
            return false;
        }
    }

    @Override
    public void modificar(Usuario usuario) {
        if (dao.modificar(usuario)) {
            this.usuario = usuario;
            Object[] mensaje = {"Registro modificado"};
            vista.notificar(mensaje);
        } else {
            Object[] mensaje = {"Error al modificar"};
            vista.notificar(mensaje);
            System.out.println(bd.getError());
        }
    }

    @Override
    public void eliminar(Usuario usuario) {
        if (dao.eliminar(usuario)) {
            this.usuario = null;
            Object[] mensaje = {"Registro eliminado"};
            vista.notificar(mensaje);
        } else {
            Object[] mensaje = {"Error al eliminar"};
            vista.notificar(mensaje);
        }
    }

    @Override
    public void filtrar(String des) {
    }

    @Override
    public void cancelar() {
    }

    @Override
    public void buscar(Usuario can) {
    }

    @Override
    public void cargar() {
        vista.mostrar(dao.listar());
    }

}
