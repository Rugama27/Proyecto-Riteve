package Dao;

import BaseDatos.BaseDatos;
import Modelo.Cita;
import Modelo.Vehiculo;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 *
 * @author Luis Rugama
 */
public class CitaDao implements Dao<Cita> {

    private BaseDatos db;

    public CitaDao(BaseDatos db) {
        this.db = db;
    }

    @Override
    public boolean insertar(Cita cita) {
        this.db.prepararSentencia("Insert into citas values (?,?,?,?)");
        Object[] param = {cita.getId(), cita.getFecha(), cita.getHora(), cita.getDatosVehiculo(),};
        return this.db.ejecutar(param);
    }

    @Override
    public boolean modificar(Cita cita, String id) {
        this.db.prepararSentencia("Update citas set IdCitas=?, Fecha=?, Hora=?, DatosVehiculos=? where IdCitas=?");
        Object[] param = {cita.getId(), cita.getFecha(), cita.getHora(), cita.getDatosVehiculo()};
        return this.db.ejecutar(param);
    }

    @Override
    public boolean eliminar(Cita citas) {
        this.db.prepararSentencia("Delete from citas where IdCitas=?");
        Object[] param = {citas.getId()};
        return this.db.ejecutar(param);
    }

    @Override
    public Cita buscar(Cita citas) {
        this.db.prepararSentencia("Select * from citas IdCitas=?");
        Object[] param = {citas.getId()};
        Object[][] valores;
        valores = this.db.seleccionar(param);
        if (valores.length > 0) {
            return new Cita((int) valores[0][0], fecha(String.valueOf(valores[0][1])), (String.valueOf(valores[0][2])), (Vehiculo) valores[0][3]);
        } else {
            return null;
        }
    }

    @Override
    public Cita[] listar() {
        this.db.prepararSentencia("Select * from citas order by IdCitas");
        Object[] param = {};
        Object[][] valores;
        valores = this.db.seleccionar(param);
        if (valores.length > 0) {
            Cita[] cita = new Cita[valores.length];
            for (int f = 0; f < valores.length; f++) {
                cita[f] = new Cita((int) valores[f][0], fecha(String.valueOf(valores[f][1])), (String.valueOf(valores[f][2])), (Vehiculo) valores[f][3]);
            }
            return cita;
        } else {
            return null;
        }
    }

    public Date fecha(String fecha) {
        try {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            java.util.Date parsed;
            parsed = format.parse(fecha);
            java.sql.Date sql = new java.sql.Date(parsed.getTime());
            return sql;
        } catch (ParseException ex) {
            return null;
        }
    }
// revisar esto 

    @Override
    public Cita[] filtrar(String nombre) {
        this.db.prepararSentencia("Select * from citas where IdCitas  like (?) order by IdCitas");
        Object[] param = {nombre + "%"};
        Object[][] valores;
        valores = this.db.seleccionar(param);
        if (valores != null && valores.length > 0) {
            Cita[] cita = new Cita[valores.length];
            for (int f = 0; f < valores.length; f++) {
                cita[f] = new Cita((int) valores[f][0], fecha(String.valueOf(valores[f][1])), (String.valueOf(valores[f][2])), (Vehiculo) valores[f][3]);
            }
            return cita;
        } else {
            return null;
        }
    }

    @Override
    public boolean validarPk(Cita cita) {
        cita = buscar(cita);
        return cita == null;
    }

}
