/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import BaseDatos.BaseDatos;
import Modelo.Vehiculo;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 *
 * @author Luis Rugama
 */
public class VehiculoDao implements Dao<Vehiculo> {

    private BaseDatos db;

    public VehiculoDao(BaseDatos db) {
        this.db = db;
    }

    @Override
    public boolean insertar(Vehiculo vehiculo) {
        this.db.prepararSentencia("Insert into vehiculos values (?,?,?,?,?,?,?)");
        Object[] param = {vehiculo.getPlaca(), vehiculo.getMarca(), vehiculo.getModelo(), vehiculo.getAño(),
            vehiculo.getFechaInscripcion(), vehiculo.getCedulaPropietario(), vehiculo.getPropietario()};
        return this.db.ejecutar(param);
    }

    @Override
    public boolean modificar(Vehiculo vehiculo, String cedula) {
        this.db.prepararSentencia("Update vehiculos set Placa=?, Marca=?, Modelo=?, Año=?, "
                + "FechaInscripcion=?, CedulaPropietario=?, Propietrario=? where Placa=?");
        Object[] param = {vehiculo.getPlaca(), vehiculo.getMarca(), vehiculo.getModelo(), vehiculo.getAño(),
            vehiculo.getFechaInscripcion(), vehiculo.getCedulaPropietario(), vehiculo.getPropietario()};
        return this.db.ejecutar(param);
    }

    @Override
    public boolean eliminar(Vehiculo vehiculo) {
        this.db.prepararSentencia("Delete from vehiculos where Placa=?");
        Object[] param = {vehiculo.getPlaca()};
        return this.db.ejecutar(param);
    }

    @Override
    public Vehiculo buscar(Vehiculo vehiculo) {
        this.db.prepararSentencia("Select * from vehiculos Placa=?");
        Object[] param = {vehiculo.getPlaca()};
        Object[][] valores;
        valores = this.db.seleccionar(param);
        if (valores.length > 0) {
            return new Vehiculo(String.valueOf(valores[0][0]), String.valueOf(valores[0][1]), String.valueOf(valores[0][2]), Año(String.valueOf(valores[0][3])),
                    fechaInscripcion(String.valueOf(valores[0][4])), (int) valores[0][5], String.valueOf(valores[0][6]));
        } else {
            return null;
        }
    }

    @Override
    public Vehiculo[] listar() {
        this.db.prepararSentencia("Select * from vehiculos order by Placa");
        Object[] param = {};
        Object[][] valores;
        valores = this.db.seleccionar(param);
        if (valores.length > 0) {
            Vehiculo[] vehiculo = new Vehiculo[valores.length];
            for (int f = 0; f < valores.length; f++) {
                vehiculo[f] = new Vehiculo(String.valueOf(valores[f][0]), String.valueOf(valores[f][1]), String.valueOf(valores[f][2]), Año(String.valueOf(valores[f][3])),
                        fechaInscripcion(String.valueOf(valores[f][4])), (int) valores[f][5], String.valueOf(valores[f][6]));

            }
            return vehiculo;
        } else {
            return null;
        }
    }

    public Date fechaInscripcion(String fecha) {
        try {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            java.util.Date parsed;
            parsed = format.parse(fecha);
            java.sql.Date sql = new java.sql.Date(parsed.getTime());
            return sql;
        } catch (ParseException ex) {
            return null;
        }
    }

    public Date Año(String fecha) {
        try {
            SimpleDateFormat format = new SimpleDateFormat("yyyy");
            java.util.Date parsed;
            parsed = format.parse(fecha);
            java.sql.Date sql = new java.sql.Date(parsed.getTime());
            return sql;
        } catch (ParseException ex) {
            return null;
        }
    }

    @Override
    public Vehiculo[] filtrar(String nombre) {
        this.db.prepararSentencia("Select * from vehiculos where NombrePropietario like (?) order by Placa");
        Object[] param = {nombre + "%"};
        Object[][] valores;
        valores = this.db.seleccionar(param);
        if (valores != null && valores.length > 0) {
            Vehiculo[] vehiculo = new Vehiculo[valores.length];
            for (int f = 0; f < valores.length; f++) {
                vehiculo[f] = new Vehiculo(String.valueOf(valores[f][0]), String.valueOf(valores[f][1]), String.valueOf(valores[f][2]), Año(String.valueOf(valores[f][3])),
                        fechaInscripcion(String.valueOf(valores[f][4])), (int) valores[f][5], String.valueOf(valores[f][6]));
            }
            return vehiculo;
        } else {
            return null;
        }
    }

    @Override
    public boolean validarPk(Vehiculo vehiculo) {
        vehiculo = buscar(vehiculo);
        return vehiculo == null;
    }

}
