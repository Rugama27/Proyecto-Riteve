package Modelo;

import java.sql.*;

/**
 *
 * @author Erick Zúñiga
 */
public class Cita {

    private int id;
    private Date fecha;
    private String hora;
    private Vehiculo datosVehiculo;

    public Cita(int id, Date fecha, String hora, Vehiculo datosVehiculo) {
        this.id = id;
        this.fecha = fecha;
        this.hora = hora;
        this.datosVehiculo = datosVehiculo;
    }

    public Cita() {
        this(0, null, null, null);
    }

    public int getId() {
        return id;
    }
    
    public Date getFecha() {
        return fecha;
    }

    public String getHora() {
        return hora;
    }

    public Vehiculo getDatosVehiculo() {
        return datosVehiculo;
    }

}
