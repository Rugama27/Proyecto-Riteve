package Modelo;

import java.sql.*;

/**
 *
 * @author Luis Rugama
 */
public class Tecnico {

    private int cedula;
    private String nombreCompleto;
    private Date fechaNacimiento;
    private int telefono;
    private String correoElectronico;
    private double salario;

    public Tecnico(int cedula, String nombreCompleto, Date fechaNacimiento, int telefono, String correoElectronico, double salario) {
        this.cedula = cedula;
        this.nombreCompleto = nombreCompleto;
        this.fechaNacimiento = fechaNacimiento;
        this.telefono = telefono;
        this.correoElectronico = correoElectronico;
        this.salario = salario;
    }

    public Tecnico() {
        this(0, null, null, 0, null, 0);
    }

    public Tecnico(String nombreCompleto) {
        this(0, nombreCompleto, null, 0, null, 0);
    }

    public Tecnico(int cedula) {
        this(cedula, null, null, 0, null, 0);
    }

    public int getCedula() {
        return cedula;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public Date getFechaNacimiento() {
        return fechaNacimiento;
    }

    public int getTelefono() {
        return telefono;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public double getSalario() {
        return salario;
    }

    public Double salarioNeto() {
        Double enfermedad = (0.055 * salario); //Enfermedad y maternidad 5.5%.
        Double invalidez = (0.0384 * salario); //Invalidez y Muerte 3.84%.
        Double aporte = (0.01 * salario); //Aporte del trabajador 1%
        Double asociacion = (0.033 * salario); //Aporte a la asociación solidarista 3.3%

        Double impuestoRenta = 0.0;
        if (salario >= 817001 && salario <= 1226000) {
            impuestoRenta = (salario * 0.1); //Impuesto de renta de 10%
        } else if (salario >= 1226001) {
            impuestoRenta = (salario * 0.15); //Impuesto de renta de 15%
        }
        return salario - enfermedad - invalidez - aporte - asociacion - impuestoRenta;
    }

}
