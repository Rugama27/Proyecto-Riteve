/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Archivo;

import java.io.IOException;

/**
 *
 * @author Alvarado Ruiz
 */
public class NewMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            Archivo archivo = new Archivo("C:\\configDB\\configDB.ini");
            archivo.abrir();
            String registro = archivo.leer();

            String[] datos = registro.split(",");
            System.out.println(datos[0].strip());
            System.out.println(datos[1].strip());
            System.out.println(datos[2].strip());
            System.out.println(datos[3].strip());

        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

}
