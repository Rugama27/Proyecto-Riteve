package Archivo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.Charset;

/**
 *
 * @author Alvarado Ruiz
 */
public class Archivo {

    private File f;
    private FileReader fr;
    private FileWriter fw;
    private BufferedReader br;
    private BufferedWriter bw;

    public Archivo(String ruta) throws IOException {
        f = new File(ruta);
    }

    public void crearArchivo() throws IOException {
        if (!f.exists()) {
            f.createNewFile();
        }
    }

    public void crearCarpeta() {
        if (!f.exists()) {
            f.mkdir();
        }
    }

    public boolean eliminar() {
        return this.f.delete();
    }

    public void abrir() throws FileNotFoundException, IOException {
        //Charset.forName("ISO-8859-1") es formato en español para el texto
        fr = new FileReader(f, Charset.forName("ISO-8859-1"));
        fw = new FileWriter(f, true);
        br = new BufferedReader(fr);
        bw = new BufferedWriter(fw);
    }

    public void cerrar() throws FileNotFoundException, IOException {
        br.close();
        bw.close();
        fr.close();
        fw.close();
    }

    public String leer() throws IOException {
        return this.br.readLine();
    }

    public void escribir(String texto) throws IOException {
        abrir();
        bw.write(texto);
    }

    public void guardar() throws IOException {
        bw.flush();
    }

}
