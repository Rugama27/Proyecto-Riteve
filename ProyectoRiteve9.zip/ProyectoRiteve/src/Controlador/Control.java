package Controlador;

/**
 *
 * @author Alvarado Ruiz
 * @param <Clase>
 */
public interface Control<Clase> {

    public void guardar(Clase clase);

    public void modificar(Clase clase, String str);

    public void eliminar(Clase clase);

    public void cancelar();

    public void filtrar(String str);
    
    public void cargar();
}
