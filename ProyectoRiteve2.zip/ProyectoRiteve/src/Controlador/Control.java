package Controlador;

/**
 *
 * @author Alvarado Ruiz
 * @param <Clase>
 */
public interface Control<Clase> {

    public void guardar(Clase clase);

    public void modificar(Clase clase);

    public void eliminar(Clase clase);

    public void cancelar();

    public void buscar(Clase clase);

    public void filtrar(String des);
    
    public void cargar();
}
